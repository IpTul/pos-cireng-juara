<?php

namespace App\Http\Controllers;

use App\Http\Requests\StoreProductRequest;
use App\Http\Requests\UpdateProductRequest;
use App\Models\Cabang;
use App\Models\Product;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Inertia\Inertia;
use Illuminate\Support\Facades\Auth;

class ProductController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    protected $user;

    public function __construct()
    {
        $this->user = auth()->user();
    }

    private function authorizeOwnerOnly()
    {
        if(! $this->user?->isOwner()) {
            abort(403, 'Hanya owner yang boleh melakukan aksi ini.');
        }
    }

    public function index(Request $request)
    {
        $user = $request->user();
        $query = Product::with('cabang');

        $activeCabangId = $this->user->activeCabangId();
        if ($activeCabangId) {
            $query->where('cabang_id', $activeCabangId);
        }

        if (request()->has('cabang_id')) {
            $query->where('cabang_id', request()->input('cabang_id'));
        }

        $sort = request()->input('sort', 'asc');

        if ($sort === 'low_stock') {
            $query->where('stock', '<', 5)->orderBy('stock', 'asc');
        } elseif ($sort === 'desc') {
            $query->orderBy('stock', 'desc');
        } else {
            $query->orderBy('stock', 'asc');
        }

        $products = $query->paginate(8)->withQueryString();

        $cabangs = Cabang::orderBy('name')
        ->get();

        return Inertia::render('products/index', [
            'products' => $products,
            'cabangs' => $cabangs,
            'user' => [
                'id' => $user->id,
                'name' => $user->name,
                'email' => $user->email,
                'role' => $user->role,
            ],
            'filters' => [
                'cabang_id' => request()->input('cabang_id'),
                'sort' => $sort,
            ]
        ]);
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(StoreProductRequest $request) : RedirectResponse
    {
        $this->authorizeOwnerOnly();
        $data = $request->validated();
        if($request->hasFile('image')) {
            $data['image'] = $request->file('image')->store('products', 'public');
        }

        Product::create($data);

        return redirect()->route('products.index')->with('success', 'Produk berhasil dibuat.');
    }

    /**
     * Display the specified resource.
     */
    public function show(Product $product)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Product $product)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(UpdateProductRequest $request, Product $product)
    {
        $this->authorizeOwnerOnly();
        $data = $request->validated();
        if($request->hasFile('image')) {
            if ($product->image) {
                Storage::disk('public')->delete($product->image);
            }
            $data['image'] = $request->file('image')->store('products', 'public');
        }

        $product->update($data);

        return redirect()->route('products.index')->with('success', 'Produk berhasil diperbarui');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Product $product)
    {
        $this->authorizeOwnerOnly();
        if ($product->image) {
            Storage::disk('public')->delete($product->image);
        }

        $product->delete();

        return redirect()->route('products.index');
    }
}
