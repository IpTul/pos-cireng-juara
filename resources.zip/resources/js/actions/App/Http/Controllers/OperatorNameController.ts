import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\OperatorNameController::show
* @see app/Http/Controllers/OperatorNameController.php:13
* @route '/operator-name'
*/
export const show = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/operator-name',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\OperatorNameController::show
* @see app/Http/Controllers/OperatorNameController.php:13
* @route '/operator-name'
*/
show.url = (options?: RouteQueryOptions) => {
    return show.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\OperatorNameController::show
* @see app/Http/Controllers/OperatorNameController.php:13
* @route '/operator-name'
*/
show.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\OperatorNameController::show
* @see app/Http/Controllers/OperatorNameController.php:13
* @route '/operator-name'
*/
show.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\OperatorNameController::show
* @see app/Http/Controllers/OperatorNameController.php:13
* @route '/operator-name'
*/
const showForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\OperatorNameController::show
* @see app/Http/Controllers/OperatorNameController.php:13
* @route '/operator-name'
*/
showForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\OperatorNameController::show
* @see app/Http/Controllers/OperatorNameController.php:13
* @route '/operator-name'
*/
showForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

show.form = showForm

/**
* @see \App\Http\Controllers\OperatorNameController::store
* @see app/Http/Controllers/OperatorNameController.php:22
* @route '/operator-name'
*/
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/operator-name',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\OperatorNameController::store
* @see app/Http/Controllers/OperatorNameController.php:22
* @route '/operator-name'
*/
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\OperatorNameController::store
* @see app/Http/Controllers/OperatorNameController.php:22
* @route '/operator-name'
*/
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\OperatorNameController::store
* @see app/Http/Controllers/OperatorNameController.php:22
* @route '/operator-name'
*/
const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\OperatorNameController::store
* @see app/Http/Controllers/OperatorNameController.php:22
* @route '/operator-name'
*/
storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

store.form = storeForm

const OperatorNameController = { show, store }

export default OperatorNameController