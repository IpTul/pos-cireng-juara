import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\SaleHistoryController::index
* @see app/Http/Controllers/SaleHistoryController.php:157
* @route '/history'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/history',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SaleHistoryController::index
* @see app/Http/Controllers/SaleHistoryController.php:157
* @route '/history'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SaleHistoryController::index
* @see app/Http/Controllers/SaleHistoryController.php:157
* @route '/history'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\SaleHistoryController::index
* @see app/Http/Controllers/SaleHistoryController.php:157
* @route '/history'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\SaleHistoryController::index
* @see app/Http/Controllers/SaleHistoryController.php:157
* @route '/history'
*/
const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\SaleHistoryController::index
* @see app/Http/Controllers/SaleHistoryController.php:157
* @route '/history'
*/
indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\SaleHistoryController::index
* @see app/Http/Controllers/SaleHistoryController.php:157
* @route '/history'
*/
indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index.form = indexForm

/**
* @see \App\Http\Controllers\SaleHistoryController::exportData
* @see app/Http/Controllers/SaleHistoryController.php:208
* @route '/history/export-data'
*/
export const exportData = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: exportData.url(options),
    method: 'get',
})

exportData.definition = {
    methods: ["get","head"],
    url: '/history/export-data',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SaleHistoryController::exportData
* @see app/Http/Controllers/SaleHistoryController.php:208
* @route '/history/export-data'
*/
exportData.url = (options?: RouteQueryOptions) => {
    return exportData.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SaleHistoryController::exportData
* @see app/Http/Controllers/SaleHistoryController.php:208
* @route '/history/export-data'
*/
exportData.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: exportData.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\SaleHistoryController::exportData
* @see app/Http/Controllers/SaleHistoryController.php:208
* @route '/history/export-data'
*/
exportData.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: exportData.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\SaleHistoryController::exportData
* @see app/Http/Controllers/SaleHistoryController.php:208
* @route '/history/export-data'
*/
const exportDataForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: exportData.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\SaleHistoryController::exportData
* @see app/Http/Controllers/SaleHistoryController.php:208
* @route '/history/export-data'
*/
exportDataForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: exportData.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\SaleHistoryController::exportData
* @see app/Http/Controllers/SaleHistoryController.php:208
* @route '/history/export-data'
*/
exportDataForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: exportData.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

exportData.form = exportDataForm

const SaleHistoryController = { index, exportData }

export default SaleHistoryController