import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\AddonController::index
* @see app/Http/Controllers/AddonController.php:26
* @route '/addons'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/addons',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\AddonController::index
* @see app/Http/Controllers/AddonController.php:26
* @route '/addons'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\AddonController::index
* @see app/Http/Controllers/AddonController.php:26
* @route '/addons'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\AddonController::index
* @see app/Http/Controllers/AddonController.php:26
* @route '/addons'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\AddonController::index
* @see app/Http/Controllers/AddonController.php:26
* @route '/addons'
*/
const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\AddonController::index
* @see app/Http/Controllers/AddonController.php:26
* @route '/addons'
*/
indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\AddonController::index
* @see app/Http/Controllers/AddonController.php:26
* @route '/addons'
*/
indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index.form = indexForm

/**
* @see \App\Http\Controllers\AddonController::store
* @see app/Http/Controllers/AddonController.php:41
* @route '/addons'
*/
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/addons',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\AddonController::store
* @see app/Http/Controllers/AddonController.php:41
* @route '/addons'
*/
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\AddonController::store
* @see app/Http/Controllers/AddonController.php:41
* @route '/addons'
*/
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\AddonController::store
* @see app/Http/Controllers/AddonController.php:41
* @route '/addons'
*/
const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\AddonController::store
* @see app/Http/Controllers/AddonController.php:41
* @route '/addons'
*/
storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

store.form = storeForm

/**
* @see \App\Http\Controllers\AddonController::update
* @see app/Http/Controllers/AddonController.php:56
* @route '/addons/{addon}'
*/
export const update = (args: { addon: number | { id: number } } | [addon: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put","patch"],
    url: '/addons/{addon}',
} satisfies RouteDefinition<["put","patch"]>

/**
* @see \App\Http\Controllers\AddonController::update
* @see app/Http/Controllers/AddonController.php:56
* @route '/addons/{addon}'
*/
update.url = (args: { addon: number | { id: number } } | [addon: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { addon: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { addon: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            addon: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        addon: typeof args.addon === 'object'
        ? args.addon.id
        : args.addon,
    }

    return update.definition.url
            .replace('{addon}', parsedArgs.addon.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AddonController::update
* @see app/Http/Controllers/AddonController.php:56
* @route '/addons/{addon}'
*/
update.put = (args: { addon: number | { id: number } } | [addon: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\AddonController::update
* @see app/Http/Controllers/AddonController.php:56
* @route '/addons/{addon}'
*/
update.patch = (args: { addon: number | { id: number } } | [addon: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

/**
* @see \App\Http\Controllers\AddonController::update
* @see app/Http/Controllers/AddonController.php:56
* @route '/addons/{addon}'
*/
const updateForm = (args: { addon: number | { id: number } } | [addon: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\AddonController::update
* @see app/Http/Controllers/AddonController.php:56
* @route '/addons/{addon}'
*/
updateForm.put = (args: { addon: number | { id: number } } | [addon: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\AddonController::update
* @see app/Http/Controllers/AddonController.php:56
* @route '/addons/{addon}'
*/
updateForm.patch = (args: { addon: number | { id: number } } | [addon: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PATCH',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

update.form = updateForm

/**
* @see \App\Http\Controllers\AddonController::destroy
* @see app/Http/Controllers/AddonController.php:71
* @route '/addons/{addon}'
*/
export const destroy = (args: { addon: number | { id: number } } | [addon: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/addons/{addon}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\AddonController::destroy
* @see app/Http/Controllers/AddonController.php:71
* @route '/addons/{addon}'
*/
destroy.url = (args: { addon: number | { id: number } } | [addon: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { addon: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { addon: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            addon: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        addon: typeof args.addon === 'object'
        ? args.addon.id
        : args.addon,
    }

    return destroy.definition.url
            .replace('{addon}', parsedArgs.addon.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AddonController::destroy
* @see app/Http/Controllers/AddonController.php:71
* @route '/addons/{addon}'
*/
destroy.delete = (args: { addon: number | { id: number } } | [addon: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

/**
* @see \App\Http\Controllers\AddonController::destroy
* @see app/Http/Controllers/AddonController.php:71
* @route '/addons/{addon}'
*/
const destroyForm = (args: { addon: number | { id: number } } | [addon: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\AddonController::destroy
* @see app/Http/Controllers/AddonController.php:71
* @route '/addons/{addon}'
*/
destroyForm.delete = (args: { addon: number | { id: number } } | [addon: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

destroy.form = destroyForm

const AddonController = { index, store, update, destroy }

export default AddonController