import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\PackController::index
* @see app/Http/Controllers/PackController.php:28
* @route '/pack'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/pack',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\PackController::index
* @see app/Http/Controllers/PackController.php:28
* @route '/pack'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\PackController::index
* @see app/Http/Controllers/PackController.php:28
* @route '/pack'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PackController::index
* @see app/Http/Controllers/PackController.php:28
* @route '/pack'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\PackController::index
* @see app/Http/Controllers/PackController.php:28
* @route '/pack'
*/
const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PackController::index
* @see app/Http/Controllers/PackController.php:28
* @route '/pack'
*/
indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PackController::index
* @see app/Http/Controllers/PackController.php:28
* @route '/pack'
*/
indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index.form = indexForm

/**
* @see \App\Http\Controllers\PackController::store
* @see app/Http/Controllers/PackController.php:58
* @route '/pack'
*/
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/pack',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\PackController::store
* @see app/Http/Controllers/PackController.php:58
* @route '/pack'
*/
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\PackController::store
* @see app/Http/Controllers/PackController.php:58
* @route '/pack'
*/
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\PackController::store
* @see app/Http/Controllers/PackController.php:58
* @route '/pack'
*/
const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\PackController::store
* @see app/Http/Controllers/PackController.php:58
* @route '/pack'
*/
storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

store.form = storeForm

/**
* @see \App\Http\Controllers\PackController::update
* @see app/Http/Controllers/PackController.php:96
* @route '/pack/{pack}'
*/
export const update = (args: { pack: number | { id: number } } | [pack: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put","patch"],
    url: '/pack/{pack}',
} satisfies RouteDefinition<["put","patch"]>

/**
* @see \App\Http\Controllers\PackController::update
* @see app/Http/Controllers/PackController.php:96
* @route '/pack/{pack}'
*/
update.url = (args: { pack: number | { id: number } } | [pack: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { pack: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { pack: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            pack: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        pack: typeof args.pack === 'object'
        ? args.pack.id
        : args.pack,
    }

    return update.definition.url
            .replace('{pack}', parsedArgs.pack.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\PackController::update
* @see app/Http/Controllers/PackController.php:96
* @route '/pack/{pack}'
*/
update.put = (args: { pack: number | { id: number } } | [pack: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\PackController::update
* @see app/Http/Controllers/PackController.php:96
* @route '/pack/{pack}'
*/
update.patch = (args: { pack: number | { id: number } } | [pack: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

/**
* @see \App\Http\Controllers\PackController::update
* @see app/Http/Controllers/PackController.php:96
* @route '/pack/{pack}'
*/
const updateForm = (args: { pack: number | { id: number } } | [pack: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\PackController::update
* @see app/Http/Controllers/PackController.php:96
* @route '/pack/{pack}'
*/
updateForm.put = (args: { pack: number | { id: number } } | [pack: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\PackController::update
* @see app/Http/Controllers/PackController.php:96
* @route '/pack/{pack}'
*/
updateForm.patch = (args: { pack: number | { id: number } } | [pack: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PATCH',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

update.form = updateForm

/**
* @see \App\Http\Controllers\PackController::destroy
* @see app/Http/Controllers/PackController.php:136
* @route '/pack/{pack}'
*/
export const destroy = (args: { pack: number | { id: number } } | [pack: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/pack/{pack}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\PackController::destroy
* @see app/Http/Controllers/PackController.php:136
* @route '/pack/{pack}'
*/
destroy.url = (args: { pack: number | { id: number } } | [pack: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { pack: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { pack: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            pack: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        pack: typeof args.pack === 'object'
        ? args.pack.id
        : args.pack,
    }

    return destroy.definition.url
            .replace('{pack}', parsedArgs.pack.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\PackController::destroy
* @see app/Http/Controllers/PackController.php:136
* @route '/pack/{pack}'
*/
destroy.delete = (args: { pack: number | { id: number } } | [pack: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

/**
* @see \App\Http\Controllers\PackController::destroy
* @see app/Http/Controllers/PackController.php:136
* @route '/pack/{pack}'
*/
const destroyForm = (args: { pack: number | { id: number } } | [pack: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\PackController::destroy
* @see app/Http/Controllers/PackController.php:136
* @route '/pack/{pack}'
*/
destroyForm.delete = (args: { pack: number | { id: number } } | [pack: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

destroy.form = destroyForm

const PackController = { index, store, update, destroy }

export default PackController