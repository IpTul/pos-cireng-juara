import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\CabangSwitchController::store
* @see app/Http/Controllers/CabangSwitchController.php:10
* @route '/switch-cabang'
*/
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/switch-cabang',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\CabangSwitchController::store
* @see app/Http/Controllers/CabangSwitchController.php:10
* @route '/switch-cabang'
*/
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\CabangSwitchController::store
* @see app/Http/Controllers/CabangSwitchController.php:10
* @route '/switch-cabang'
*/
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\CabangSwitchController::store
* @see app/Http/Controllers/CabangSwitchController.php:10
* @route '/switch-cabang'
*/
const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\CabangSwitchController::store
* @see app/Http/Controllers/CabangSwitchController.php:10
* @route '/switch-cabang'
*/
storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

store.form = storeForm

const CabangSwitchController = { store }

export default CabangSwitchController