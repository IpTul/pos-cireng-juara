import DashboardController from './DashboardController'
import PackController from './PackController'
import ProductController from './ProductController'
import CabangController from './CabangController'
import PosController from './PosController'
import SOPController from './SOPController'
import SaleHistoryController from './SaleHistoryController'
import CheckoutController from './CheckoutController'
import FinancialReportController from './FinancialReportController'
import StockAdjustmentController from './StockAdjustmentController'
import UserController from './UserController'
import AddonController from './AddonController'
import MemberController from './MemberController'
import MemberHistoryController from './MemberHistoryController'
import OperatorNameController from './OperatorNameController'
import CabangSwitchController from './CabangSwitchController'
import Settings from './Settings'

const Controllers = {
    DashboardController: Object.assign(DashboardController, DashboardController),
    PackController: Object.assign(PackController, PackController),
    ProductController: Object.assign(ProductController, ProductController),
    CabangController: Object.assign(CabangController, CabangController),
    PosController: Object.assign(PosController, PosController),
    SOPController: Object.assign(SOPController, SOPController),
    SaleHistoryController: Object.assign(SaleHistoryController, SaleHistoryController),
    CheckoutController: Object.assign(CheckoutController, CheckoutController),
    FinancialReportController: Object.assign(FinancialReportController, FinancialReportController),
    StockAdjustmentController: Object.assign(StockAdjustmentController, StockAdjustmentController),
    UserController: Object.assign(UserController, UserController),
    AddonController: Object.assign(AddonController, AddonController),
    MemberController: Object.assign(MemberController, MemberController),
    MemberHistoryController: Object.assign(MemberHistoryController, MemberHistoryController),
    OperatorNameController: Object.assign(OperatorNameController, OperatorNameController),
    CabangSwitchController: Object.assign(CabangSwitchController, CabangSwitchController),
    Settings: Object.assign(Settings, Settings),
}

export default Controllers