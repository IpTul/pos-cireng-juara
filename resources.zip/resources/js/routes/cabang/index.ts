import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../wayfinder'
/**
* @see \App\Http\Controllers\CabangSwitchController::switchMethod
* @see app/Http/Controllers/CabangSwitchController.php:10
* @route '/switch-cabang'
*/
export const switchMethod = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: switchMethod.url(options),
    method: 'post',
})

switchMethod.definition = {
    methods: ["post"],
    url: '/switch-cabang',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\CabangSwitchController::switchMethod
* @see app/Http/Controllers/CabangSwitchController.php:10
* @route '/switch-cabang'
*/
switchMethod.url = (options?: RouteQueryOptions) => {
    return switchMethod.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\CabangSwitchController::switchMethod
* @see app/Http/Controllers/CabangSwitchController.php:10
* @route '/switch-cabang'
*/
switchMethod.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: switchMethod.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\CabangSwitchController::switchMethod
* @see app/Http/Controllers/CabangSwitchController.php:10
* @route '/switch-cabang'
*/
const switchMethodForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: switchMethod.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\CabangSwitchController::switchMethod
* @see app/Http/Controllers/CabangSwitchController.php:10
* @route '/switch-cabang'
*/
switchMethodForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: switchMethod.url(options),
    method: 'post',
})

switchMethod.form = switchMethodForm

const cabang = {
    switch: Object.assign(switchMethod, switchMethod),
}

export default cabang