import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../wayfinder'
/**
* @see \App\Http\Controllers\StockAdjustmentController::index
* @see app/Http/Controllers/StockAdjustmentController.php:21
* @route '/stok'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/stok',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\StockAdjustmentController::index
* @see app/Http/Controllers/StockAdjustmentController.php:21
* @route '/stok'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\StockAdjustmentController::index
* @see app/Http/Controllers/StockAdjustmentController.php:21
* @route '/stok'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\StockAdjustmentController::index
* @see app/Http/Controllers/StockAdjustmentController.php:21
* @route '/stok'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\StockAdjustmentController::index
* @see app/Http/Controllers/StockAdjustmentController.php:21
* @route '/stok'
*/
const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\StockAdjustmentController::index
* @see app/Http/Controllers/StockAdjustmentController.php:21
* @route '/stok'
*/
indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\StockAdjustmentController::index
* @see app/Http/Controllers/StockAdjustmentController.php:21
* @route '/stok'
*/
indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index.form = indexForm

/**
* @see \App\Http\Controllers\StockAdjustmentController::store
* @see app/Http/Controllers/StockAdjustmentController.php:52
* @route '/stok'
*/
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/stok',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\StockAdjustmentController::store
* @see app/Http/Controllers/StockAdjustmentController.php:52
* @route '/stok'
*/
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\StockAdjustmentController::store
* @see app/Http/Controllers/StockAdjustmentController.php:52
* @route '/stok'
*/
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\StockAdjustmentController::store
* @see app/Http/Controllers/StockAdjustmentController.php:52
* @route '/stok'
*/
const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\StockAdjustmentController::store
* @see app/Http/Controllers/StockAdjustmentController.php:52
* @route '/stok'
*/
storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

store.form = storeForm

const stok = {
    index: Object.assign(index, index),
    store: Object.assign(store, store),
}

export default stok