import { usePage, router } from '@inertiajs/react';
import {
  LayoutGrid,
  Package,
  Tag,
  ShoppingCart,
  History,
  NotebookText,
  Wallet,
  Users,
  Activity,
  PlusCircle,
  UserPlus,
} from 'lucide-react';
import { NavMain } from '@/components/nav-main';
import { NavUser } from '@/components/nav-user';
import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarGroup,
  SidebarGroupLabel,
  SidebarHeader,
} from '@/components/ui/sidebar';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import type { NavItem, Cabang, User } from '@/types';

export function AppSidebar() {
  const { auth, cabangs, activeCabangId, operatorName } = usePage()
    .props as unknown as {
    auth: { user: User };
    cabangs: Cabang[];
    activeCabangId: number | null;
    operatorName: string | null;
  };

  function handleCabangSwitch(value: string) {
    router.post(
      '/switch-cabang',
      { cabang_id: value === 'all' ? null : value },
      { preserveScroll: true },
    );
  }

  const posItems: NavItem[] = [
    {
      title: 'Jual',
      href: '/pos',
      icon: ShoppingCart,
    },
  ];

  const operationalItems: NavItem[] = [
    {
      title: 'Halaman Utama',
      href: '/dashboard',
      icon: LayoutGrid,
    },
  ];

  const catalogItems: NavItem[] = [
    {
      title: 'Produk',
      href: '/products',
      icon: Package,
    },
    {
      title: 'Riwayat Stok',
      href: '/stok',
      icon: Activity,
    },
    {
      title: 'Paket',
      href: '/pack',
      icon: Package,
    },
    {
      title: 'Member',
      href: '/members',
      icon: UserPlus,
    },
    {
      title: 'Riwayat Transaksi',
      href: '/history',
      icon: History,
    },
  ];

  const managementItems: NavItem[] = [
    {
      title: 'Addon',
      href: '/addons',
      icon: PlusCircle,
    },
    {
      title: 'Cabang',
      href: '/cabangs',
      icon: Tag,
    },
    { title: 'Keuangan', href: '/keuangan', icon: Wallet },
    { title: 'Manajemen Pengguna', href: '/users', icon: Users },
  ];

  const otherItems: NavItem[] = [
    {
      title: 'SOP',
      href: '/sop',
      icon: NotebookText,
    },
  ];

  // const financeItems: NavItem[] = [
  //   { title: 'Keuangan', href: '/keuangan', icon: Wallet },
  // ];

  // const settingsItems: NavItem[] = [
  //   { title: 'Manajemen Pengguna', href: '/users', icon: Users },
  // ];

  return (
    <Sidebar>
      <SidebarHeader className="border-b px-3 py-4">
        <div className="flex items-center gap-2.5">
          <img
            src="/logo-cireng.png"
            alt="Cireng Juara"
            className="size-10 object-contain"
          />
          <div className="flex flex-col leading-tight">
            <span className="text-sm font-semibold">Cireng Juara</span>
            {operatorName && (
              <span className="text-xs text-muted-foreground">
                Operator : {operatorName}
              </span>
            )}
          </div>
        </div>

        {auth.user?.role === 'owner' && (
          <Select
            value={activeCabangId ? String(activeCabangId) : 'all'}
            onValueChange={handleCabangSwitch}
          >
            <SelectTrigger className="mt-2 w-full">
              <SelectValue placeholder="Semua Cabang  " />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Semua Cabang</SelectItem>
              {cabangs?.map((c) => (
                <SelectItem key={c.id} value={String(c.id)}>
                  {c.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        )}
      </SidebarHeader>

      <SidebarContent className="gap-2 py-2">
        <SidebarGroup>
          <NavMain items={posItems} />
          <NavMain items={otherItems} />
        </SidebarGroup>

        <SidebarGroup>
          <SidebarGroupLabel>Operasional</SidebarGroupLabel>
          <NavMain items={operationalItems} />
        </SidebarGroup>

        <SidebarGroup>
          <SidebarGroupLabel>Produk</SidebarGroupLabel>
          <NavMain items={catalogItems} />
        </SidebarGroup>

        {auth.user?.role === 'owner' && (
          <SidebarGroup>
            <SidebarGroupLabel>Manajemen</SidebarGroupLabel>
            <NavMain items={managementItems} />
          </SidebarGroup>
        )}

        {/* {auth.user?.role === 'owner' && (
          <SidebarGroup>
            <SidebarGroupLabel>Manajemen</SidebarGroupLabel>
            <NavMain items={financeItems} />
          </SidebarGroup>
        )}

        {auth.user?.role === 'owner' && (
          <SidebarGroup>
            <SidebarGroupLabel>Pengaturan</SidebarGroupLabel>
            <NavMain items={settingsItems} />
          </SidebarGroup>
        )} */}
      </SidebarContent>

      <SidebarFooter className="border-t px-2 py-3">
        <NavUser />
      </SidebarFooter>
    </Sidebar>
  );
}