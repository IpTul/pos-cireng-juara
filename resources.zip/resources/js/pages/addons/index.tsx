import { useState } from 'react';
import { usePage, router, Head } from '@inertiajs/react';
import { toast } from 'sonner';
import { Plus, Edit, Trash2, X, Check } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import Heading from '@/components/heading';
import { formatRupiah } from '@/lib/utils';
import type { Addon, Cabang } from '@/types';

interface PaginatedAddons {
  data: Addon[];
  links: { url: string | null; label: string; active: boolean }[];
  from: number;
  to: number;
  total: number;
}

export default function AddonIndex() {
  const { addons, cabangs } = usePage().props as unknown as {
    addons: PaginatedAddons;
    cabangs: Cabang[];
  };
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingAddon, setEditingAddon] = useState<Addon | null>(null);
  const [formData, setFormData] = useState({
    name: '',
    cabang_id: '' as string | number,
    description: '',
    price: 0,
    is_active: true,
  });
  const [submitting, setSubmitting] = useState(false);

  function openCreateDialog() {
    setEditingAddon(null);
    setFormData({
      name: '',
      cabang_id: '',
      description: '',
      price: 0,
      is_active: true,
    });
    setIsDialogOpen(true);
  }

  function openEditDialog(addon: Addon) {
    setEditingAddon(addon);
    setFormData({
      name: addon.name,
      cabang_id: addon.cabang_id ?? '',
      description: addon.description ?? '',
      price: parseFloat(addon.price),
      is_active: addon.is_active,
    });
    setIsDialogOpen(true);
  }

  function closeDialog() {
    setIsDialogOpen(false);
    setEditingAddon(null);
    setFormData({
      name: '',
      cabang_id: '',
      description: '',
      price: 0,
      is_active: true,
    });
  }

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setSubmitting(true);

    const method = editingAddon ? 'put' : 'post';
    const url = editingAddon ? `/addons/${editingAddon.id}` : '/addons';

    router[method](url, formData, {
      onSuccess: () => {
        toast.success(
          editingAddon
            ? 'Addon berhasil diperbarui.'
            : 'Addon berhasil ditambahkan.',
        );
        closeDialog();
        setSubmitting(false);
      },
      onError: (errors) => {
        toast.error(Object.values(errors).flat().join(', '));
        setSubmitting(false);
      },
    });
  }

  function handleDelete(addon: Addon) {
    if (!confirm(`Yakin ingin menghapus "${addon.name}"?`)) return;

    router.delete(`/addons/${addon.id}`, {
      onSuccess: () => toast.success('Addon berhasil dihapus.'),
      onError: () => toast.error('Gagal menghapus addon.'),
    });
  }

  return (
    <>
      <Head title="Addons" />
      <div className="p-6">
        <div className="mb-4 flex items-center justify-between">
          <h1 className="text-2xl font-bold">Addons</h1>
          <Button onClick={openCreateDialog}>
            <Plus className="mr-2 h-4 w-4" />
            Tambah Addon
          </Button>
        </div>
        <div className="rounded-lg border">
          <table className="w-full text-sm">
            <thead className="border-b bg-muted/50">
              <tr>
                <th className="px-4 py-3 text-left">Nama</th>
                <th className="px-4 py-3 text-left">Deskripsi</th>
                <th className="px-4 py-3 text-left">Harga</th>
                <th className="px-4 py-3 text-left">Status</th>
                <th className="px-4 py-3 text-right">Aksi</th>
              </tr>
            </thead>
            <tbody>
              {addons.data.map((addon: Addon) => (
                <tr
                  key={addon.id}
                  className="border-b transition-colors hover:bg-muted/25"
                >
                  <td className="px-4 py-3 font-medium">{addon.name}</td>
                  <td className="px-4 py-3 font-medium">
                    {addon.description || '-'}
                  </td>
                  <td className="px-4 py-3 font-medium">
                    {formatRupiah(parseFloat(addon.price))}
                  </td>
                  <td className="px-4 py-3 text-left">
                    <Switch
                      checked={addon.is_active}
                      onCheckedChange={(checked: boolean) => {
                        router.put(`/addons/${addon.id}`, {
                          name: addon.name,
                          description: addon.description ?? '',
                          price: parseFloat(addon.price),
                          is_active: checked,
                        });
                      }}
                      disabled={submitting}
                    />
                  </td>
                  <td className="py-3 text-right font-medium">
                    <div className="flex items-center justify-end gap-2">
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => openEditDialog(addon)}
                        disabled={submitting}
                      >
                        <Edit className="h-4 w-4" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => handleDelete(addon)}
                        disabled={submitting}
                        className="text-destructive hover:bg-destructive/10 hover:text-destructive"
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>

          {addons.data.length === 0 && (
            <div className="py-12 text-center text-muted-foreground">
              Belum ada addon. Klik "Tambah Addon" untuk memulai.
            </div>
          )}

          {addons.links.length > 1 && (
            <div className="flex items-center justify-between border-t px-4 py-3">
              <span className="text-sm text-muted-foreground">
                Menampilkan {addons.from} - {addons.to} dari {addons.total}{' '}
                addon
              </span>
              <nav className="flex items-center gap-1" aria-label="Pagination">
                {addons.links.map((link) =>
                  link.url ? (
                    <Button
                      key={link.url}
                      variant="ghost"
                      size="sm"
                      className={link.active ? 'bg-muted' : ''}
                      onClick={(e) => {
                        e.preventDefault();
                        router.get(link.url!, { preserveScroll: true });
                      }}
                    >
                      {link.label}
                    </Button>
                  ) : (
                    <span
                      key={link.label}
                      className="px-2 text-muted-foreground"
                    >
                      {link.label}
                    </span>
                  ),
                )}
              </nav>
            </div>
          )}
        </div>

        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle>
                {editingAddon ? 'Edit Addon' : 'Tambah Addon Baru'}
              </DialogTitle>
              <DialogDescription>
                {editingAddon
                  ? 'Perbarui informasi addon di bawah ini.'
                  : 'Isi form di bawah untuk menambahkan addon baru.'}
              </DialogDescription>
            </DialogHeader>
            <form onSubmit={handleSubmit}>
              <div className="grid gap-4 py-4">
                <div className="grid gap-2">
                  <Label htmlFor="name">Nama Addon *</Label>
                  <Input
                    id="name"
                    placeholder="Contoh: Mentai, Chilli Oil"
                    value={formData.name}
                    onChange={(e) =>
                      setFormData({ ...formData, name: e.target.value })
                    }
                    required
                    disabled={submitting}
                  />
                </div>

                <div className="grid gap-2">
                  <Label htmlFor="addon-cabang">Cabang *</Label>
                  <Select
                    value={formData.cabang_id ? String(formData.cabang_id) : ''}
                    onValueChange={(value) =>
                      setFormData({ ...formData, cabang_id: value })
                    }
                  >
                    <SelectTrigger id="addon-cabang" disabled={submitting}>
                      <SelectValue placeholder="Pilih cabang" />
                    </SelectTrigger>
                    <SelectContent>
                      {cabangs?.map((c) => (
                        <SelectItem key={c.id} value={String(c.id)}>
                          {c.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="grid gap-2">
                  <Label htmlFor="description">Deskripsi</Label>
                  <Textarea
                    id="description"
                    placeholder="Deskripsi singkat addon"
                    value={formData.description}
                    onChange={(e) =>
                      setFormData({ ...formData, description: e.target.value })
                    }
                    rows={3}
                    disabled={submitting}
                  />
                </div>
                <div className="grid gap-2">
                  <Label htmlFor="price">Harga (Rp) *</Label>
                  <Input
                    id="price"
                    type="number"
                    step="500"
                    min="0"
                    placeholder="0"
                    value={formData.price}
                    onChange={(e) =>
                      setFormData({
                        ...formData,
                        price: parseInt(e.target.value) || 0,
                      })
                    }
                    required
                    disabled={submitting}
                  />
                </div>
                <div className="flex items-center justify-between">
                  <Label htmlFor="is_active">Aktif</Label>
                  <Switch
                    id="is_active"
                    checked={formData.is_active}
                    onCheckedChange={(checked: boolean) =>
                      setFormData({ ...formData, is_active: checked })
                    }
                    disabled={submitting}
                  />
                </div>
              </div>
              <DialogFooter className="gap-2">
                <Button
                  type="button"
                  variant="outline"
                  onClick={closeDialog}
                  disabled={submitting}
                >
                  <X className="mr-2 h-4 w-4" />
                  Batal
                </Button>
                <Button type="submit" disabled={submitting}>
                  {submitting
                    ? 'Menyimpan...'
                    : editingAddon
                      ? 'Simpan Perubahan'
                      : 'Tambah Addon'}
                  {!submitting && <Check className="ml-2 h-4 w-4" />}
                </Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>
      </div>
    </>
  );
}

AddonIndex.layout = {
  breadcrumbs: [{ title: 'Addons', href: '/addons' }],
};
