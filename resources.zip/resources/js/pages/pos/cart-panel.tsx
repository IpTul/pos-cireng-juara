import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Trash2, Package, Gift, Plus, Minus } from 'lucide-react';
import {
  CartItem,
  PackCartItem,
  Product,
  Addon,
  AddonSelection,
  PackVariant,
} from '@/types';
import FreeProductModal from './free-product-modal';
import PackVariantModal from './pack-variant-modal';
import { FreeItemSelection } from './use-cart';
import { Badge } from '@/components/ui/badge';

interface Props {
  items: (
    | (CartItem & {
        freeQuantity?: number;
        totalQuantity?: number;
        freeItems?: FreeItemSelection[];
      })
    | (PackCartItem & {
        freeQuantity?: number;
        totalQuantity?: number;
        freeItems?: FreeItemSelection[];
        variants?: PackVariant[];
      })
  )[];
  subtotal: number;
  totalItems: number;
  onRemoveProduct: (productId: number) => void;
  onRemovePack: (packId: number) => void;
  onSetProductQuantity: (productId: number, qty: number) => void;
  onSetPackQuantity: (packId: number, qty: number) => void;
  onClear: () => void;
  onCheckout: () => void;
  products: Product[];
  availableAddons: Addon[];
  cartAddons: AddonSelection[];
  onSetFreeItems: (freeItems: FreeItemSelection[]) => void;
  onAddAddon: (addon: Addon) => void;
  onRemoveAddon: (addonId: number) => void;
  onSetPackVariants: (packId: number, variants: PackVariant[]) => void;
}

function isCartItem(item: Props['items'][0]): item is CartItem & {
  freeQuantity?: number;
  totalQuantity?: number;
  freeItems?: FreeItemSelection[];
} {
  return 'product' in item;
}

function isPackCartItem(item: Props['items'][0]): item is PackCartItem & {
  freeQuantity?: number;
  totalQuantity?: number;
  freeItems?: FreeItemSelection[];
  variants?: PackVariant[];
} {
  return 'pack' in item;
}

function formatRupiah(value: string | number) {
  return `Rp${Math.round(Number(value)).toLocaleString('id-ID')}`;
}

export default function CartPanel({
  items,
  subtotal,
  totalItems,
  onRemoveProduct,
  onRemovePack,
  onSetProductQuantity,
  onSetPackQuantity,
  onClear,
  onCheckout,
  products,
  availableAddons,
  cartAddons,
  onSetFreeItems,
  onAddAddon,
  onRemoveAddon,
  onSetPackVariants,
}: Props) {
  const [modalOpen, setModalOpen] = useState(false);
  const [selectedItemId, setSelectedItemId] = useState<number | null>(null);
  const [selectedItemName, setSelectedItemName] = useState('');
  const [selectedMaxFree, setSelectedMaxFree] = useState(0);
  const [selectedCurrentFree, setSelectedCurrentFree] = useState<
    FreeItemSelection[]
  >([]);
  const [packVariantModal, setPackVariantModal] = useState<{
    open: boolean;
    pack: any | null;
    variants: PackVariant[] | null;
  }>({
    open: false,
    pack: null,
    variants: null,
  });

  function openPackVariantModal(packItem: any, variants: PackVariant[] = []) {
    setPackVariantModal({
      open: true,
      pack: packItem.pack,
      variants: variants,
    });
  }

  function handlePackVariantsConfirm(variants: PackVariant[]) {
    if (packVariantModal.pack && packVariantModal.variants !== null) {
      onSetPackVariants(packVariantModal.pack.id, variants);
    }
    setPackVariantModal({ open: false, pack: null, variants: null });
  }

  function handlePackVariantsCancel() {
    setPackVariantModal({ open: false, pack: null, variants: null });
  }

  function openFreeModal(item: Props['items'][0]) {
    const freeQty = item.freeQuantity || 0;
    if (freeQty > 0) {
      const itemId = isCartItem(item) ? item.product.id : item.pack.id;
      const itemName = isCartItem(item) ? item.product.name : item.pack.name;
      setSelectedItemId(itemId);
      setSelectedItemName(itemName);
      setSelectedMaxFree(freeQty);
      setSelectedCurrentFree(item.freeItems || []);
      setModalOpen(true);
    }
  }

  function handleFreeItemsConfirm(freeItems: FreeItemSelection[]) {
    onSetFreeItems(freeItems);
    setModalOpen(false);
  }

  return (
    <>
      <div className="flex h-full min-h-0 w-full flex-col bg-card md:w-80 md:shrink-0 md:border-l [@media(max-height:500px)]:md:w-96">
        <div className="flex items-center justify-between border-b px-4 py-3 [@media(max-height:500px)]:py-1.5">
          <h2 className="font-semibold">Keranjang</h2>
          {items.length > 0 && (
            <button
              onClick={onClear}
              className="text-xs text-muted-foreground hover:text-destructive"
            >
              Kosongkan
            </button>
          )}
        </div>
        <div className="min-h-0 flex-1 space-y-3 overflow-y-auto p-4 [@media(max-height:500px)]:p-2">
          {items.length === 0 ? (
            <p className="py-8 text-center text-sm text-muted-foreground">
              Belum ada item.
            </p>
          ) : (
            items.map((item, index) => (
              <div
                key={index}
                className="flex flex-col gap-2 [@media(max-height:500px)]:gap-1"
              >
                <div className="flex items-start gap-2">
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-1">
                      <p className="truncate text-sm font-medium">
                        {isCartItem(item)
                          ? item.product.name
                          : `[Paket] ${item.pack.name}`}
                      </p>
                      {isPackCartItem(item) && (
                        <Package className="h-3 w-3 text-primary" />
                      )}
                    </div>
                    {isCartItem(item) ? (
                      <p className="text-xs text-muted-foreground">
                        {formatRupiah(item.product.price)}
                      </p>
                    ) : (
                      <>
                        {item.variants && item.variants.length > 0 ? (
                          <div className="space-y-1 text-xs text-muted-foreground">
                            {item.variants.map((variant, idx) => (
                              <p key={idx}>
                                {variant.product.name} x{variant.quantity}
                              </p>
                            ))}
                          </div>
                        ) : (
                          <p className="text-xs text-muted-foreground">
                            {item.pack.pack_items
                              ?.map(
                                (pi) => `${pi.product.name} x${pi.quantity}`,
                              )
                              .join(', ')}
                          </p>
                        )}
                        <Button
                          variant="ghost"
                          size="icon"
                          className="mt-1 h-5 w-5 p-0 text-xs hover:text-primary"
                          onClick={() =>
                            openPackVariantModal(item, item.variants || [])
                          }
                        >
                          <span className="text-[10px]">Edit</span>
                        </Button>
                      </>
                    )}
                    {(item.freeQuantity ?? 0) > 0 && (
                      <div className="mt-1 flex items-center gap-2">
                        <p className="flex items-center gap-1 text-xs text-green-600">
                          <Gift className="h-3 w-3" />
                          Gratis {item.freeQuantity}
                        </p>
                        {(!item.freeItems ||
                          item.freeItems.length === 0 ||
                          item.freeItems.reduce((s, f) => s + f.quantity, 0) <
                            item.freeQuantity!) && (
                          <Button
                            variant="outline"
                            size="sm"
                            style={{
                              padding: '0 8px',
                              height: '24px',
                              fontSize: '11px',
                            }}
                            onClick={() => openFreeModal(item)}
                          >
                            Pilih Gratis
                          </Button>
                        )}
                        {item.freeItems &&
                          item.freeItems.reduce((s, f) => s + f.quantity, 0) >=
                            item.freeQuantity! && (
                            <Badge variant="default" className="text-xs">
                              Selesai
                            </Badge>
                          )}
                      </div>
                    )}
                    {item.stock <= 0 && (
                      <p className="mt-2 text-xs text-destructive">
                        Stok habis — produk tidak dapat ditambahkan
                      </p>
                    )}
                  </div>
                  <Input
                    type="number"
                    min={1}
                    max={
                      item.stock <= 0
                        ? 0
                        : isCartItem(item)
                          ? item.product.stock
                          : 999
                    }
                    disabled={item.stock <= 0}
                    value={item.quantity}
                    onChange={(e) => {
                      const qty = parseInt(e.target.value) || 0;
                      if (isCartItem(item)) {
                        onSetProductQuantity(item.product.id, qty);
                      } else {
                        onSetPackQuantity(item.pack.id, qty);
                      }
                    }}
                    className="w-16 text-center [@media(max-height:500px)]:h-8"
                  />
                  <span className="w-16 text-center text-xs text-muted-foreground">
                    Total: {item.totalQuantity ?? item.quantity}
                  </span>
                  <button
                    onClick={() => {
                      if (isCartItem(item)) {
                        onRemoveProduct(item.product.id);
                      } else {
                        onRemovePack(item.pack.id);
                      }
                    }}
                    className="text-destructive hover:opacity-70"
                  >
                    <Trash2 className="h-4 w-4" />
                  </button>
                </div>
              </div>
            ))
          )}

          {items.length > 0 && availableAddons.length > 0 && (
            <div className="border-t pt-3">
              <p className="mb-2 text-xs font-medium text-muted-foreground">
                Addon (untuk transaksi ini):
              </p>
              <div className="flex flex-wrap gap-1">
                {availableAddons.map((addon) => {
                  const selected = cartAddons.find(
                    (a) => a.addon.id === addon.id,
                  );
                  const qty = selected?.quantity || 0;
                  return (
                    <div
                      key={addon.id}
                      className={`flex items-center gap-1 rounded border px-2 py-1 text-xs ${
                        qty > 0
                          ? 'border-primary bg-primary/10'
                          : 'border-muted'
                      }`}
                    >
                      <span>{addon.name}</span>
                      <span className="text-muted-foreground">
                        ({formatRupiah(addon.price)})
                      </span>
                      {qty > 0 ? (
                        <>
                          <button
                            onClick={() => onRemoveAddon(addon.id)}
                            className="hover:text-destructive"
                          >
                            <Minus className="h-3 w-3" />
                          </button>
                          <span>{qty}</span>
                          <button
                            onClick={() => onAddAddon(addon)}
                            className="hover:text-primary"
                          >
                            <Plus className="h-3 w-3" />
                          </button>
                        </>
                      ) : (
                        <button
                          onClick={() => onAddAddon(addon)}
                          className="hover:text-primary"
                        >
                          <Plus className="h-3 w-3" />
                        </button>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </div>
        <div className="shrink-0 space-y-3 border-t p-4 [@media(max-height:500px)]:space-y-1 [@media(max-height:500px)]:p-2">
          <div className="flex justify-between text-sm text-muted-foreground [@media(max-height:500px)]:hidden">
            <span>Item dibayar</span>
            <span>{items.reduce((sum, i) => sum + i.quantity, 0)}</span>
          </div>
          <div className="flex justify-between text-sm text-green-600 [@media(max-height:500px)]:hidden">
            <span>Gratis (Beli 10 Gratis 1)</span>
            <span>
              {items.reduce((sum, i) => sum + (i.freeQuantity || 0), 0)}
            </span>
          </div>
          <div className="flex justify-between text-lg font-bold [@media(max-height:500px)]:text-sm">
            <span>Total Item</span>
            <span>{totalItems}</span>
          </div>
          <div className="flex justify-between text-lg font-bold [@media(max-height:500px)]:text-sm">
            <span>Total Bayar</span>
            <span>{formatRupiah(subtotal)}</span>
          </div>
          <Button
            className="w-full [@media(max-height:500px)]:h-8"
            size="lg"
            disabled={items.length === 0}
            onClick={onCheckout}
          >
            Bayar
          </Button>
        </div>
      </div>

      <FreeProductModal
        open={modalOpen}
        onClose={() => setModalOpen(false)}
        onConfirm={handleFreeItemsConfirm}
        products={products}
        maxFreeQuantity={selectedMaxFree}
        itemName={selectedItemName}
        itemId={selectedItemId || 0}
        currentSelections={selectedCurrentFree}
      />
      <PackVariantModal
        open={packVariantModal.open}
        onClose={handlePackVariantsCancel}
        onConfirm={handlePackVariantsConfirm}
        pack={packVariantModal.pack!}
        products={products}
        currentVariants={packVariantModal.variants || []}
      />
    </>
  );
}
